# mip-hc360-performace

mip-hc360-performace mip栈发送曝光数据

标题|内容
----|----
类型|通用
支持布局|responsive,fixed-height,fill,container,fixed
所需脚本|https://mipcache.bdstatic.com/static/v1/mip-hc360-performace/mip-hc360-performace.js

## 示例

### 基本用法
```html
<mip-hc360-performace word="hello"></mip-hc360-performace>
```

## 属性

### word

说明：曝光数据类型
必选项：否
类型：String
取值范围：hello, hi, six
